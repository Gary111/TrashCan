package com.igortyulkanov.routebuildersample.mvp;

public interface MvpView {

    void runOnUIThread(Runnable runnable);

}