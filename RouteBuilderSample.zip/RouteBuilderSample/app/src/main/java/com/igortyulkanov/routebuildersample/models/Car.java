package com.igortyulkanov.routebuildersample.models;

public class Car {

    public final Location location;

    public Car(Location location) {
        this.location = location;
    }

}
